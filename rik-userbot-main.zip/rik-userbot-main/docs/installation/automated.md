---
title: Автоматическая установка
layout: default
parent: Установка
nav_order: 2
---

# {{ page.title }}

Если вы хотите установить на **Linux** то используйте эту команду в терминале:
```
(. <($(which curl>/dev/null&&echo curl -Ls||echo wget -qO-) https://raw.githubusercontent.com/LORD-ME-CODE/lordnet-userbot/master/install.sh))
```

Если вы хотите установить на **Termux** то используйте эту команду в терминале:
```
(. <($(which curl>/dev/null&&echo curl -Ls||echo wget -qO-) https://raw.githubusercontent.com/LORD-ME-CODE/lordnet-userbot/master/termux.sh))
```

![img.png](../assets/screenshot.png)
