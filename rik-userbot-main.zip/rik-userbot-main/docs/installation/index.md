---
title: Установка
layout: default
nav_order: 1
has_children: true
---

# {{ page.title }}

Существует несколько способов установки. Я рекомендую Автоматический