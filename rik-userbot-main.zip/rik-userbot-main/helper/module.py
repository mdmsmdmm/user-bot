#
#  _    ___  ___ ___  _  _ ___ _____    _   _ ___ ___ ___ ___  ___ _____
# | |  / _ \| _ \   \| \| | __|_   _|__| | | / __| __| _ \ _ )/ _ \_   _|
# | |_| (_) |   / |) | .` | _|  | ||___| |_| \__ \ _||   / _ \ (_) || |
# |____\___/|_|_\___/|_|\_|___| |_|     \___/|___/___|_|_\___/\___/ |_|
#
#                            © Copyright 2022
#
#                       https://t.me/lordnet_userbot
#
# 🔒 Licensed under the GNU GPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html

import asyncio
import logging
from importlib import import_module
from pathlib import Path

from threading import Thread

import pyrogram
from pyrogram.errors import MessageIdInvalid
from pyrogram.handlers import MessageHandler
from helper.misc import modules_dict, prefix
from helper.misc import session, lordnet_url
from typing import Any
from errors import *


def get_commands(x: tuple):
    return x[0] if len(x) > 0 and isinstance(x[0], (list, tuple)) else None


# noinspection PyIncorrectDocstring
def module(*filters, **params):
    """
    Декоратор для модулей reider-userbot

    Parameters:
        filters (``Any``, *optional*):
            Пирограм фильтры для модуля.
        commands (``list or str``, *required if filters is not used*):
            Список команд или одна команда для модуля.
        description (``str``, *optional*):
            Описание команд (показывается в help)
        args (``list or str``, *optional*):
            Аргументы для команды (показывается в help)
    """

    if not params and not filters:
        raise IndexError("Не указаны аргументы для модуля")
    elif filters and isinstance(filters[0], str):
        logging.warning(
            "Вы не указали ничего в @module декораторе, проверьте пожалуйста."
        )

    commands = (
        params.get("commands")
        or params.get("command")
        or params.get("cmds")
        or get_commands(filters)
    )
    if isinstance(commands, str):
        commands = [commands]
    elif isinstance(commands, list):
        commands = commands
    elif (
        not isinstance(commands, list) and not isinstance(commands, str) and not filters
    ):
        raise TypeError("Команды должны быть типа строка или список")

    module_value = get_module_name(inspect.getmodule(inspect.stack()[1][0]))

    if not modules_dict.module_in(module_value):
        modules_dict[module_value] = {
            "commands": [],
        }

    if commands:
        args = params.get("args") or params.get("arguments") or []
        if isinstance(args, str):
            args = [args]
        modules_dict.add_command(
            module_value,
            {
                "name": commands,
                "desc": params.get("desc")
                or params.get("description")
                or "Без описания",
                "args": args,
            },
        )
        if not filters:
            insp = False
            filters = pyrogram.filters.command(commands, prefix()) & pyrogram.filters.me
        else:
            insp = True
    else:
        insp = True

    if isinstance(filters, (list, tuple)) and len(filters) == 1:
        filters = filters[0]

    def sub_decorator(func):
        is_coroutine = inspect.iscoroutinefunction(func)
        if insp:
            if is_coroutine:

                async def wrapper(*xds, **kwargs):
                    try:
                        await func(*xds, **kwargs)
                    except (pyrogram.StopPropagation, pyrogram.ContinuePropagation):
                        raise pyrogram.ContinuePropagation
                    except Exception as ex:
                        return await error_handler_async(xds[0], ex, xds[1])
                    else:
                        raise pyrogram.ContinuePropagation

            else:

                def wrapper(*xds, **kwargs):
                    try:
                        func(*xds, **kwargs)
                    except (pyrogram.StopPropagation, pyrogram.ContinuePropagation):
                        raise pyrogram.ContinuePropagation
                    except Exception as ex:
                        return error_handler_sync(xds[0], ex, xds[1])
                    else:
                        raise pyrogram.ContinuePropagation

        elif is_coroutine:

            async def wrapper(*xds, **kwargs):
                try:
                    await func(*xds, **kwargs)
                except (pyrogram.StopPropagation, pyrogram.ContinuePropagation):
                    raise pyrogram.ContinuePropagation
                except Exception as ex:
                    await error_handler_async(xds[0], ex, xds[1])

        else:

            def wrapper(*xds, **kwargs):
                try:
                    func(*xds, **kwargs)
                except (pyrogram.StopPropagation, pyrogram.ContinuePropagation):
                    raise pyrogram.ContinuePropagation
                except Exception as ex:
                    error_handler_sync(xds[0], ex, xds[1])

        handler = MessageHandler(wrapper, filters)
        if "handlers" not in modules_dict[module_value]:
            modules_dict[module_value]["handlers"] = []
        modules_dict.client.add_handler(handler)
        modules_dict[module_value]["handlers"].append(handler)

        return wrapper

    return sub_decorator


def _preload_module(path, is_basic: bool = False):
    global imported, exceptions

    module_path = ".".join(path.parent.parts + (path.stem,))
    try:
        if is_basic:
            import_module(module_path)
            modules_dict[module_path]["made_by"] = "@reiderub"
        else:
            load_module(module_path)
        imported += 1
    except Exception as e:
        exceptions += 1
        logging.warning(
            f"Не удалось импортировать {module_path}: {e.__class__.__name__}: {e}"
        )


imported, exceptions = 0, 0


def load_modules(loop=None):
    global imported, exceptions

    logging.info("[_] Загружаю модули...")

    if loop:
        asyncio.set_event_loop(loop)

    preloads = []

    for path in Path("modules").rglob("*.py"):
        pre = Thread(target=_preload_module, args=(path, True))
        pre.start()
        preloads.append(pre)

    for path in Path("custom").rglob("*.py"):
        pre = Thread(target=_preload_module, args=(path,))
        pre.start()
        preloads.append(pre)

    for pre in preloads:
        pre.join()

    logging.info(f"[+] Загружено {imported} модулей!")
    imported = 0
    if exceptions:
        logging.warning(f"[-] {exceptions} модулей не удалось загрузить!")
        exceptions = 0


def load_module(module_name: str):
    mod = import_module(module_name, package="__main__")
    made_by = getattr(mod, "made_by", "@Неизвестный")[:64]
    modules_dict[module_name]["made_by"] = made_by
    if module_name in modules_dict.deleted:
        modules_dict.remove(module_name)


async def unload_module(module_name: str):
    try:
        handlers = modules_dict[module_name]["handlers"]
        for handler in handlers:
            modules_dict.client.remove_handler(handler)
        modules_dict.remove(module_name)
        modules_dict.deleted.append(module_name)
    except KeyError:
        pass


async def all_off_modules():
    avaiable_modules = await session.get(lordnet_url + "all.py")
    if not avaiable_modules.ok:
        return []
    text = await avaiable_modules.text()
    return text.strip().split("\n")


async def module_exists(module_name: str):
    return module_name in await all_off_modules()


def escape_html(text: Any) -> str:
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


async def answer(message: pyrogram.types.Message, text: str):
    try:
        await message.edit(
            text
        ) if message.from_user.id == modules_dict.client.me.id else await message.reply(
            text
        )
    except MessageIdInvalid:
        await message.reply(text)
