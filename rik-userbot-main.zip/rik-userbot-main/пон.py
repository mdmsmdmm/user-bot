# -*- coding: utf-8 -*-
import logging
import pip
import os

requirements = ["install", "environs", "psutil", "aiohttp", "validators", "aiofile", "GitPython", "tgcrypto"]




def c():
    pip.main(requirements)

if __name__ == "__main__":
    c()


